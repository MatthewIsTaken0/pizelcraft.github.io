﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WeAreDevs_API;

namespace Phantom
{
    public partial class Phantom : Form
    {

        WebClient wc = new WebClient();
        ExploitAPI api = new ExploitAPI();

        public Phantom()
        {
            InitializeComponent();
        }

        private void Phantom_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();//Clear Items in the LuaScriptList
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            OpenFileDialog opendialogfile = new OpenFileDialog();
            opendialogfile.Filter = "Lua File (*.lua)|*.lua|Text File (*.txt)|*.txt";
            opendialogfile.FilterIndex = 2;
            opendialogfile.RestoreDirectory = true;
            if (opendialogfile.ShowDialog() != DialogResult.OK)
                return;
            try
            {
                LuaBox.Text = "";
                System.IO.Stream stream;
                if ((stream = opendialogfile.OpenFile()) == null)
                    return;
                using (stream)
                    this.LuaBox.Text = System.IO.File.ReadAllText(opendialogfile.FileName);
            }
            catch (Exception ex)
            {
                int num = (int)MessageBox.Show("An unexpected error has occured", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();//Clear Items in the LuaScriptList
            Functions.PopulateListBox(listBox1, "./Scripts", "*.txt");
            Functions.PopulateListBox(listBox1, "./Scripts", "*.lua");
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e) => LuaBox.Text = File.ReadAllText($"./Scripts/{listBox1.SelectedItem}");

        private void button3_Click(object sender, EventArgs e)
        {
            api.LaunchExploit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            api.SendLuaScript(LuaBox.Text + wc.DownloadString("https://pastebin.com/raw/92BgPGUY"));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            LuaBox.Clear();
        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void button17_Click(object sender, EventArgs e)
        {
            api.SendLuaScript("for a,b in pairs(getreg()) do \nif typeof(b) == \"function\" then \nfor c,d in pairs(debug.getupvalues(b)) do \nif typeof(d) == \"table\" and d.FireServer then\nlocal FS = d.FireServer\nd.FireServer = function(a1, ...)\nif typeof(({...})[2]) == \"number\" and game:GetService(\"Players\").LocalPlayer.Character:FindFirstChild(\"InVehicle\") then \nreturn FS(a1, ({...})[1], -math.huge)\nelse\nreturn FS(a1, ...)\nend\nend\nend\nend\nend\nend");
        }

        private void button16_Click(object sender, EventArgs e)
        {
            api.SendLuaScript("local GunModifications = {\n \"CamShakeMagnitude\",\n \"FireFreq\",\n \"MagSize\",\n \"FireAuto\",\n \"BulletSpeed\",\n \"Bullet Spread\",\n \"BulletsPerShot\"\n }\n function ModifyWeaponValue(value, temp_var_1)\n for i,v in next, getgc() do\n if type(v) == \"table\" then\n for i2, v2 in next, v do\n if tostring(i2) == \"CamShakeMagnitude\" then\n v[value] = temp_var_1\n end\n end\n end\n end\n end\n ModifyWeaponValue(GunModifications[1], 0);\n ModifyWeaponValue(GunModifications[2], 10000);\n ModifyWeaponValue(GunModifications[3], math.huge);\n ModifyWeaponValue(GunModifications[4], true);\n ModifyWeaponValue(GunModifications[5], 100000000);\n ModifyWeaponValue(GunModifications[6], 1110);\n ModifyWeaponValue(GunModifications[7], 10);\n");
        }

        private void button15_Click(object sender, EventArgs e)
        {
            api.SendLuaScript(wc.DownloadString("https://pastebin.com/raw/CiJtg36J"));
        }

        private void button14_Click(object sender, EventArgs e)
        {
            api.SendLuaScript("getsenv(game:GetService(\"Players\").LocalPlayer.PlayerScripts.LocalScript).tick = function() return 0/0 end");
        }

        private void button13_Click(object sender, EventArgs e)
        {
            api.SendLuaScript(wc.DownloadString("https://pastebin.com/raw/WXUMi7jJ"));
        }

        private void button12_Click(object sender, EventArgs e)
        {
            api.SendLuaScript(wc.DownloadString("https://pastebin.com/raw/KhGigW1W"));
        }
    }
}
