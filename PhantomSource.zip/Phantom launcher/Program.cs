﻿using System;
using System.Diagnostics;
using System.Net;
using System.Runtime.InteropServices;

namespace Phantom_launcher
{
    class Program
    {

        [DllImport("user32.dll", CharSet = CharSet.Auto, ExactSpelling = true)]
        public static extern bool MessageBeep(int type);
        [DllImport("kernel32.dll")]
        private static extern int Beep(int dwFreq, int dwDuration);

        static void Main(string[] args)
        {
            Console.WriteLine(@"
            
            
            ██████╗░██╗░░██╗░█████╗░███╗░░██╗████████╗░█████╗░███╗░░░███╗
            ██╔══██╗██║░░██║██╔══██╗████╗░██║╚══██╔══╝██╔══██╗████╗░████║
            ██████╔╝███████║███████║██╔██╗██║░░░██║░░░██║░░██║██╔████╔██║
            ██╔═══╝░██╔══██║██╔══██║██║╚████║░░░██║░░░██║░░██║██║╚██╔╝██║
            ██║░░░░░██║░░██║██║░░██║██║░╚███║░░░██║░░░╚█████╔╝██║░╚═╝░██║
            ╚═╝░░░░░╚═╝░░╚═╝╚═╝░░╚═╝╚═╝░░╚══╝░░░╚═╝░░░░╚════╝░╚═╝░░░░░╚═╝
            
            
            █▀▄▀█ ▄▀█ █▀▄ █▀▀   █▄▄ █▄█   ▄▀█ █▀█ █▀█ █▄▄ ▄▀█ █▀█ █▀▀ █▀▀ █ █▀▀ █ ▄▀█ █░░   █▀█ █▄░█
            █░▀░█ █▀█ █▄▀ ██▄   █▄█ ░█░   █▀█ █▀▄ █▄█ █▄█ █▀█ █▄█ █▀░ █▀░ █ █▄▄ █ █▀█ █▄▄   █▄█ █░▀█

            █░█░█ █▀▀ ▄▀█ █▀█ █▀▀ █▀▄ █▀▀ █░█ █▀
            ▀▄▀▄▀ ██▄ █▀█ █▀▄ ██▄ █▄▀ ██▄ ▀▄▀ ▄█
            
            
            ***ALWAYS OPEN THIS TO INSTALL UPDATES!***
            
            ");
            WebClient wc = new WebClient();
            wc.DownloadFile("https://raw.githubusercontent.com/MatthewIsTaken0/save/master/Phantom.exe", "Phantom.exe");
            Beep(800, 2000);
            Console.WriteLine("You can now open Phantom.exe!");
            Console.ReadKey();
        }
    }
}
