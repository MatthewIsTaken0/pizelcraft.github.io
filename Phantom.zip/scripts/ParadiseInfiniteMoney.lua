--https://www.roblox.com/games/4241242833/Family-Paradise

local ScreenGui = Instance.new("ScreenGui")
local Main = Instance.new("ImageLabel")
local DesignA = Instance.new("ImageLabel")
local ParadiseInfMoney = Instance.new("TextLabel")
local DesignB = Instance.new("ImageLabel")
local Subscribetopizzaprimeonyt = Instance.new("TextLabel")
local DesignC = Instance.new("ImageLabel")
local JoinmyDiscordforhelpItsinthenotepad = Instance.new("TextLabel")
local InfiniteMoney = Instance.new("TextButton")
local InfiniteSpeed = Instance.new("TextButton")
local Extra = Instance.new("TextLabel")
local Rejoingametostopmoneygen = Instance.new("TextLabel")
local Gamelinkisinthenotepad = Instance.new("TextLabel")
local warning = Instance.new("ImageButton")
local warning_2 = Instance.new("ImageButton")
local DesignD = Instance.new("ImageLabel")
local AlsojoinmyDiscordforFEfeatures = Instance.new("TextLabel")
 
--Properties:
 
ScreenGui.Parent = game.CoreGui
 
Main.Name = "Main"
Main.Parent = ScreenGui
Main.Active = true
Main.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Main.BackgroundTransparency = 1.000
Main.BorderSizePixel = 0
Main.Position = UDim2.new(0.22516042, 0, 0.22799097, 0)
Main.Selectable = true
Main.Size = UDim2.new(0, 219, 0, 326)
Main.Image = "http://www.roblox.com/asset/?id=4499750415"
Main.Draggable = true
 
DesignA.Name = "DesignA"
DesignA.Parent = Main
DesignA.Active = true
DesignA.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
DesignA.BackgroundTransparency = 1.000
DesignA.BorderSizePixel = 0
DesignA.Selectable = true
DesignA.Size = UDim2.new(0, 219, 0, 28)
DesignA.Image = "http://www.roblox.com/asset/?id=3558795340"
 
ParadiseInfMoney.Name = "Paradise Inf Money"
ParadiseInfMoney.Parent = DesignA
ParadiseInfMoney.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
ParadiseInfMoney.BackgroundTransparency = 4.000
ParadiseInfMoney.Size = UDim2.new(0, 219, 0, 28)
ParadiseInfMoney.Font = Enum.Font.SourceSans
ParadiseInfMoney.Text = "Paradise Inf Money"
ParadiseInfMoney.TextColor3 = Color3.fromRGB(0, 0, 0)
ParadiseInfMoney.TextSize = 20.000
 
DesignB.Name = "DesignB"
DesignB.Parent = Main
DesignB.Active = true
DesignB.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
DesignB.BackgroundTransparency = 1.000
DesignB.BorderSizePixel = 0
DesignB.Position = UDim2.new(0, 0, 0.910256386, 0)
DesignB.Selectable = true
DesignB.Size = UDim2.new(0, 219, 0, 28)
DesignB.Image = "http://www.roblox.com/asset/?id=3558795340"
 
Subscribetopizzaprimeonyt.Name = "-Subscribe to pizza prime on yt"
Subscribetopizzaprimeonyt.Parent = DesignB
Subscribetopizzaprimeonyt.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Subscribetopizzaprimeonyt.BackgroundTransparency = 5.000
Subscribetopizzaprimeonyt.Size = UDim2.new(0, 219, 0, 28)
Subscribetopizzaprimeonyt.Font = Enum.Font.SourceSans
Subscribetopizzaprimeonyt.Text = "-Subscribe to pizza prime on yt"
Subscribetopizzaprimeonyt.TextColor3 = Color3.fromRGB(0, 0, 0)
Subscribetopizzaprimeonyt.TextSize = 14.000
 
DesignC.Name = "DesignC"
DesignC.Parent = Main
DesignC.Active = true
DesignC.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
DesignC.BackgroundTransparency = 1.000
DesignC.BorderSizePixel = 0
DesignC.Position = UDim2.new(0, 0, 0.837606847, 0)
DesignC.Selectable = true
DesignC.Size = UDim2.new(0, 219, 0, 25)
DesignC.Image = "http://www.roblox.com/asset/?id=3558795340"
 
JoinmyDiscordforhelpItsinthenotepad.Name = "-Join my Discord for help(Its in the notepad)"
JoinmyDiscordforhelpItsinthenotepad.Parent = DesignC
JoinmyDiscordforhelpItsinthenotepad.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
JoinmyDiscordforhelpItsinthenotepad.BackgroundTransparency = 5.000
JoinmyDiscordforhelpItsinthenotepad.Size = UDim2.new(0, 219, 0, 25)
JoinmyDiscordforhelpItsinthenotepad.Font = Enum.Font.SourceSans
JoinmyDiscordforhelpItsinthenotepad.Text = "-Join my Discord for help(Its in the notepad)"
JoinmyDiscordforhelpItsinthenotepad.TextColor3 = Color3.fromRGB(0, 0, 0)
JoinmyDiscordforhelpItsinthenotepad.TextSize = 14.000
 
InfiniteMoney.Name = "Infinite Money"
InfiniteMoney.Parent = Main
InfiniteMoney.BackgroundColor3 = Color3.fromRGB(217, 184, 255)
InfiniteMoney.BorderColor3 = Color3.fromRGB(0, 170, 255)
InfiniteMoney.Position = UDim2.new(0.0809960142, 0, 0.158685595, 0)
InfiniteMoney.Size = UDim2.new(0, 182, 0, 56)
InfiniteMoney.Font = Enum.Font.SourceSans
InfiniteMoney.Text = "Infinite Money"
InfiniteMoney.TextColor3 = Color3.fromRGB(0, 0, 0)
InfiniteMoney.MouseButton1Down:connect(function()
while true do
    local part = Instance.new("Part",game.Workspace)
    wait(0)
 
 
game.ReplicatedStorage.Remotes.BasicRemoteEvent:InvokeServer("Payment")end
end)
InfiniteMoney.TextSize = 20.000
 
InfiniteSpeed.Name = "Infinite Speed"
InfiniteSpeed.Parent = Main
InfiniteSpeed.BackgroundColor3 = Color3.fromRGB(247, 183, 255)
InfiniteSpeed.BorderColor3 = Color3.fromRGB(0, 0, 255)
InfiniteSpeed.Position = UDim2.new(0.0776255727, 0, 0.581196606, 0)
InfiniteSpeed.Size = UDim2.new(0, 182, 0, 50)
InfiniteSpeed.Font = Enum.Font.SourceSans
InfiniteSpeed.Text = "Infinite Speed"
InfiniteSpeed.TextColor3 = Color3.fromRGB(0, 0, 0)
InfiniteSpeed.TextSize = 20.000
InfiniteSpeed.MouseButton1Down:connect(function()
while true do
    local part = Instance.new("Part",game.Workspace)
    wait(0.1)
   
 
game.ReplicatedStorage.Remotes.BasicEvent:FireServer("Run")end
end)
 
Extra.Name = "Extra"
Extra.Parent = Main
Extra.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Extra.BackgroundTransparency = 5.000
Extra.Position = UDim2.new(0.118721455, 0, 0.475783467, 0)
Extra.Size = UDim2.new(0, 165, 0, 31)
Extra.Font = Enum.Font.SourceSans
Extra.Text = "Extra"
Extra.TextColor3 = Color3.fromRGB(0, 0, 0)
Extra.TextSize = 18.000
 
Rejoingametostopmoneygen.Name = "Rejoin game to stop money gen"
Rejoingametostopmoneygen.Parent = Main
Rejoingametostopmoneygen.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Rejoingametostopmoneygen.BackgroundTransparency = 5.000
Rejoingametostopmoneygen.Position = UDim2.new(0.0867579877, 0, 0.333333343, 0)
Rejoingametostopmoneygen.Size = UDim2.new(0, 180, 0, 26)
Rejoingametostopmoneygen.Font = Enum.Font.SourceSans
Rejoingametostopmoneygen.Text = "Rejoin game to stop money gen"
Rejoingametostopmoneygen.TextColor3 = Color3.fromRGB(0, 0, 0)
Rejoingametostopmoneygen.TextSize = 14.000
 
Gamelinkisinthenotepad.Name = "Game link is in the notepad."
Gamelinkisinthenotepad.Parent = Main
Gamelinkisinthenotepad.BackgroundColor3 = Color3.fromRGB(145, 111, 255)
Gamelinkisinthenotepad.Position = UDim2.new(0, 0, 0.740740716, 0)
Gamelinkisinthenotepad.Size = UDim2.new(0, 219, 0, 25)
Gamelinkisinthenotepad.Font = Enum.Font.SourceSans
Gamelinkisinthenotepad.Text = "Game link is in the notepad."
Gamelinkisinthenotepad.TextColor3 = Color3.fromRGB(0, 0, 0)
Gamelinkisinthenotepad.TextSize = 17.000
 
warning.Name = "warning"
warning.Parent = Main
warning.BackgroundTransparency = 1.000
warning.Position = UDim2.new(0.87214613, 0, 0.908831894, 0)
warning.Size = UDim2.new(0, 25, 0, 25)
warning.ZIndex = 2
warning.Image = "rbxassetid://3926305904"
warning.ImageRectOffset = Vector2.new(364, 324)
warning.ImageRectSize = Vector2.new(36, 36)
 
warning_2.Name = "warning"
warning_2.Parent = Main
warning_2.BackgroundTransparency = 1.000
warning_2.Position = UDim2.new(0.00456621125, 0, 0.908831894, 0)
warning_2.Size = UDim2.new(0, 25, 0, 25)
warning_2.ZIndex = 2
warning_2.Image = "rbxassetid://3926305904"
warning_2.ImageRectOffset = Vector2.new(364, 324)
warning_2.ImageRectSize = Vector2.new(36, 36)
 
DesignD.Name = "DesignD"
DesignD.Parent = Main
DesignD.Active = true
DesignD.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
DesignD.BackgroundTransparency = 1.000
DesignD.BorderSizePixel = 0
DesignD.Position = UDim2.new(0, 0, 0.99750936, 0)
DesignD.Selectable = true
DesignD.Size = UDim2.new(0, 219, 0, 31)
DesignD.Image = "http://www.roblox.com/asset/?id=4499764013"
 
AlsojoinmyDiscordforFEfeatures.Name = "Also join my Discord for FE features"
AlsojoinmyDiscordforFEfeatures.Parent = Main
AlsojoinmyDiscordforFEfeatures.BackgroundColor3 = Color3.fromRGB(1, 200, 255)
AlsojoinmyDiscordforFEfeatures.Position = UDim2.new(-0.00456620986, 0, 1, 0)
AlsojoinmyDiscordforFEfeatures.Size = UDim2.new(0, 220, 0, 30)
AlsojoinmyDiscordforFEfeatures.Font = Enum.Font.SourceSans
AlsojoinmyDiscordforFEfeatures.Text = "Also join my Discord for FE features."
AlsojoinmyDiscordforFEfeatures.TextColor3 = Color3.fromRGB(0, 0, 0)
AlsojoinmyDiscordforFEfeatures.TextSize = 18.000